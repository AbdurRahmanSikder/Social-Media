login & register page
feed page
profile page
picture
story feature
edit details
share to story
search accounts